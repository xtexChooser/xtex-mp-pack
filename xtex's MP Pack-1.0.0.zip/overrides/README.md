# xtex's MP Pack

> Minecraft modpack focusing on multiplayer (Survival, Creative or PvP) performance and experience optimization.

### Building

This pack is built with [packwiz](https://github.com/packwiz/packwiz). So just run `packwiz modrinth export`

### TODO

- Chest Tracker(waiting for 1.19.3)